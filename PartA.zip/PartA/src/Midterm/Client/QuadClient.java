package Midterm.Client;
import java.io.File;
import java.util.Scanner;
import java.util.Vector;
import java.io.IOException;
import Midterm.Service.*;;
public class QuadClient {
	public static void main(String args[]){
		String line = new String();
		String [] txt_data;
		House data;

		try{
			File textFile = new File("/Users/mofadesewaatanda/Desktop/HomeTxt.txt");
			Scanner scan = new Scanner(textFile);
			
			while(scan.hasNextLine())
			{
				line=scan.nextLine();				
				txt_data = line.split(":");
				data = new House(txt_data[0], Double.parseDouble(txt_data[1]), Double.parseDouble(txt_data[2]));
				House.hse_vec.add(data);
				for (int i = 0; i < House.hse_vec.size(); ++i) {
					for(int j = 0; j < House.hse_vec.size(); ++j) {
						if(House.hse_vec.elementAt(i).getName().equals(House.hse_vec.elementAt(j).getName()) && (i != j)) {
							House.hse_vec.elementAt(i).setNumMen(House.hse_vec.elementAt(i).getNumMen()+House.hse_vec.elementAt(j).getNumMen());
							House.hse_vec.elementAt(i).setNumWomen(House.hse_vec.elementAt(i).getNumWomen()+House.hse_vec.elementAt(j).getNumWomen());
							House.hse_vec.remove(j);
							
						}
					} 	
					
				}
				
			}
			
				House swap;
				for(int i = 0; i < House.hse_vec.size()-1; ++i) {
					for(int j = 0; j < House.hse_vec.size()-i-1; j++) {
						if(House.hse_vec.get(j).ratioMaleFemale() > House.hse_vec.get(j+1).ratioMaleFemale()) {
							
							swap=House.hse_vec.get(j);
							House.hse_vec.set(j, House.hse_vec.get(j+1));
							House.hse_vec.set(j+1,swap);
								
						}
						
					}
				}
						
				for(int i=0;i<House.hse_vec.size();i++) {
					System.out.println(House.hse_vec.elementAt(i));
					System.out.println(House.hse_vec.elementAt(i).ratioMaleFemale());
					
				}
		
			
		}catch(IOException e){
			System.out.println("Issuse with reading the file. Aborting");
			System.out.println(e.getMessage());
		}
		//boolean duplicate = data.equals(txt_data);
		
		
	}	


}
