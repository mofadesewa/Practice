package Midterm.Service;

import java.util.Vector;

public class House {
	private String name;
	private Double numMen;
	private Double numWomen;
	public static Vector<House> hse_vec = new Vector<>();
	

	public House(String name, Double numMen, Double numWomen) {
		this.setName(name);
		this.setNumMen(numMen);
		this.setNumWomen(numWomen);
	}
	public House() {
		
	}

	public void setName(String n) {
		this.name = n;
	}
	public String getName() {
		return this.name;
	}
	public void setNumMen(Double men) {
		this.numMen = men;
	}
	public Double getNumMen() {
		return this.numMen;
	}
	public void setNumWomen(Double women) {
		this.numWomen = women;
	}
	public Double getNumWomen() {
		return this.numWomen;
	}
	
	public String toString() {
		String str = "Name:" + this.getName() + " Number of men:" + this.getNumMen() + " Number of women:" + this.getNumWomen();
		return str;
	}
	public double ratioMaleFemale() {
		if (numWomen == 0) {
			System.out.println("There are no women in the house");
		}
		else if (numMen < 0 || numWomen < 0) {
			System.out.println("Number of people cannot be negative");
		}
		double ratio = (Double)numMen/(Double)numWomen;
		return ratio;	
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
