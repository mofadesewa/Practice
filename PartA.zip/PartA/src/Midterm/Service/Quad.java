package Midterm.Service;


public class Quad {
	private int size;

	public Quad() {
		size = 12;
	}

	public Quad(int size) {
		this.setSize(size);
	}

	private void setSize(int s) {
		this.size = s;
	}
	private int getSize() {
		return this.size;
	}
	private double checkSize() {
		int num = size;
		return num;	
	}
	private boolean addHouse() {
		if (size < 12) {
			size++;
		}
		return true;
	}
	public String toString() {
		String str = "Number of houses is: " + this.getSize();
		return str;
	}

}
