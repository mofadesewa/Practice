/**
 * 
 */
/**
 * @author mofadesewaatanda
 *
 */
module PartA {
}